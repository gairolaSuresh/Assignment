const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const testScore = new Schema({
   
});

module.exports=mongoose.model('testScore',testScore)